import java.awt.Color;
import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;

import Profile.mainprofile;
import MyPortfolio.design_HomePage;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class IntegrationProgram extends JFrame {
	
	private JPanel contentPane;
	private JButton dan;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					IntegrationProgram frame = new IntegrationProgram();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public IntegrationProgram() {
		setBounds(100, 100, 975, 580);
		getContentPane().setLayout(null);
		
		JLabel portfolio = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("/Portfolio.png")).getImage();
		
		JButton carl = new JButton("View Portfolio");
		carl.setForeground(Color.WHITE);
		carl.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				carl.setForeground(Color.DARK_GRAY);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				carl.setForeground(Color.WHITE);
			}
		});
		carl.setFocusPainted(false);
		carl.setOpaque(false);
		carl.setContentAreaFilled(false);
		carl.setBorderPainted(false);
		carl.setFont(new Font("Century Gothic", Font.BOLD, 20));
		carl.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				design_HomePage hp = new design_HomePage();
				hp.setVisible(true);
				hp.setLocationRelativeTo(null);
				}
		});
		dan = new JButton("View Portfolio");
		dan.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				dan.setForeground(Color.LIGHT_GRAY);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				dan.setForeground(Color.BLACK);
			}
		});
		dan.setFocusPainted(false);
		dan.setOpaque(false);
		dan.setContentAreaFilled(false);
		dan.setBorderPainted(false);
		dan.setFont(new Font("Century Gothic", Font.BOLD, 20));
		dan.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mainprofile mp = new mainprofile();
				mp.setVisible(true);
				mp.setLocationRelativeTo(null);
				}
		});
		dan.setBounds(634, 384, 198, 23);
		getContentPane().add(dan);
		carl.setBounds(110, 380, 260, 30);
		getContentPane().add(carl);
		portfolio.setIcon(new ImageIcon(img));
		portfolio.setBounds(0, 0, 959, 540);
		getContentPane().add(portfolio);
	}
}
