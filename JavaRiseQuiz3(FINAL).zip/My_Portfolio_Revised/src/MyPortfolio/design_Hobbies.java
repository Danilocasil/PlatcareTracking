package MyPortfolio;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class design_Hobbies extends JFrame {

	private JPanel contentPane;
	//instantiation
	Strs_N_Wkns ins = new Strs_N_Wkns();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					design_Hobbies frame = new design_Hobbies();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public design_Hobbies() {
		setTitle("My Portfolio - Hobbies");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 897, 516);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btn_return = new JButton("Return");
		btn_return.setBackground(new Color(0, 0, 0));
		btn_return.setForeground(new Color(255, 255, 255));
		btn_return.setFont(new Font("Century Gothic", Font.BOLD, 15));
		btn_return.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				design_HomePage page = new design_HomePage();
				page.show();
				dispose();
			}
		});
		btn_return.setBounds(719, 425, 108, 28);
		btn_return.setFocusable(false);
		btn_return.setBorderPainted(false);
		contentPane.add(btn_return);
		
		JLabel lbl_games = new JLabel(ins.games);
		lbl_games.setForeground(new Color(255, 255, 255));
		lbl_games.setFont(new Font("Century Gothic", Font.BOLD, 16));
		lbl_games.setBounds(52, 224, 218, 22);
		contentPane.add(lbl_games);
		
		JLabel lbl_music = new JLabel(ins.music);
		lbl_music.setForeground(Color.WHITE);
		lbl_music.setFont(new Font("Century Gothic", Font.BOLD, 16));
		lbl_music.setBounds(52, 351, 218, 22);
		contentPane.add(lbl_music);
		
		JLabel lbl_films = new JLabel(ins.films);
		lbl_films.setForeground(Color.WHITE);
		lbl_films.setFont(new Font("Century Gothic", Font.BOLD, 16));
		lbl_films.setBounds(471, 224, 218, 22);
		contentPane.add(lbl_films);
		
		JLabel lbl_sports = new JLabel(ins.sports);
		lbl_sports.setForeground(Color.WHITE);
		lbl_sports.setFont(new Font("Century Gothic", Font.BOLD, 16));
		lbl_sports.setBounds(471, 351, 218, 22);
		contentPane.add(lbl_sports);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(0, 0, 883, 479);
		lblNewLabel.setIcon(new ImageIcon(design_Hobbies.class.getResource("/images/Hobbies.png")));
		contentPane.add(lblNewLabel);
	}

}
