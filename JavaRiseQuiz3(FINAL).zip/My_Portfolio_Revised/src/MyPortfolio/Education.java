package MyPortfolio;

public class Education extends Hobbies{

	String elem = "Teodora Alonzo Elementary School";
	String hs = "Jose P. Laurel Sr. High School";
	String shs = "JCSGO Christian Academy";
	String college = "National University - Manila";
	
}
