package MyPortfolio;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import java.awt.Toolkit;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class design_AboutMe extends JFrame {

	private JPanel contentPane;
	
	//instantiation
	Strs_N_Wkns ins = new Strs_N_Wkns();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					design_AboutMe frame = new design_AboutMe();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public design_AboutMe() {
		setResizable(false);
		setTitle("My Portfolio - About Me");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 900, 518);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btn_return = new JButton("Return");
		btn_return.setBackground(new Color(0, 0, 0));
		btn_return.setForeground(new Color(255, 255, 255));
		btn_return.setFont(new Font("Century Gothic", Font.BOLD, 15));
		btn_return.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				design_HomePage page = new design_HomePage();
				page.show();
				dispose();
			}
		});
		btn_return.setBounds(719, 425, 108, 28);
		btn_return.setFocusable(false);
		btn_return.setBorderPainted(false);
		contentPane.add(btn_return);
		
		JLabel lbl_religion = new JLabel(ins.religion);
		lbl_religion.setBounds(601, 267, 155, 23);
		lbl_religion.setForeground(new Color(255, 255, 255));
		lbl_religion.setFont(new Font("Century Gothic", Font.BOLD, 15));
		contentPane.add(lbl_religion);
		
		JLabel lbl_prefLang = new JLabel(ins.prefLanguage);
		lbl_prefLang.setBounds(591, 213, 155, 23);
		lbl_prefLang.setForeground(new Color(255, 255, 255));
		lbl_prefLang.setFont(new Font("Century Gothic", Font.BOLD, 15));
		contentPane.add(lbl_prefLang);
		
		JLabel lbl_nationality = new JLabel(ins.nationality);
		lbl_nationality.setBounds(632, 158, 155, 23);
		lbl_nationality.setForeground(new Color(255, 255, 255));
		lbl_nationality.setFont(new Font("Century Gothic", Font.BOLD, 15));
		contentPane.add(lbl_nationality);
		
		JLabel lbl_livingIn = new JLabel(ins.live);
		lbl_livingIn.setBounds(250, 272, 155, 23);
		lbl_livingIn.setForeground(new Color(255, 255, 255));
		lbl_livingIn.setFont(new Font("Century Gothic", Font.BOLD, 15));
		contentPane.add(lbl_livingIn);
		
		JLabel lbl_hometown = new JLabel(ins.homeTown);
		lbl_hometown.setBounds(244, 213, 120, 23);
		lbl_hometown.setForeground(new Color(255, 255, 255));
		lbl_hometown.setFont(new Font("Century Gothic", Font.BOLD, 15));
		contentPane.add(lbl_hometown);
		
		JLabel lbl_bdate = new JLabel(ins.bday);
		lbl_bdate.setBounds(220, 158, 155, 23);
		lbl_bdate.setForeground(new Color(255, 255, 255));
		lbl_bdate.setFont(new Font("Century Gothic", Font.BOLD, 15));
		contentPane.add(lbl_bdate);
		
		JLabel AboutMePage = new JLabel("");
		AboutMePage.setBounds(0, 0, 886, 481);
		AboutMePage.setIcon(new ImageIcon(design_AboutMe.class.getResource("/images/About Me (1).png")));
		contentPane.add(AboutMePage);
				
				
				

	}
}
