package MyPortfolio;

public class Hobbies extends Skills{

	String games = "PLAYING VIDEO GAMES";
	String music = "LISTENING TO MUSIC";
	String films = "WATCHING FILMS";
	String sports = "PLAYING SPORTS";
}
