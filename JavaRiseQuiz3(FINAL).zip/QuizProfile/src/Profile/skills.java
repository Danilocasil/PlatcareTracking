package Profile;

import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Font;
import java.awt.Color;

public class skills extends JFrame {
	personality pers = new personality();

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					skills frame = new skills();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public skills() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1239, 724);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel skills = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("/Skills.png")).getImage();
		Image img2 = new ImageIcon(this.getClass().getResource("/back.png")).getImage();
		
		JLabel skill = new JLabel("");
		skill.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				mainprofile mp = new mainprofile();
				mp.setVisible(true);
				mp.setLocationRelativeTo(null);
				dispose();
			}
		});
		
		JLabel pub = new JLabel(pers.pub);
		pub.setForeground(Color.DARK_GRAY);
		pub.setFont(new Font("Constantia", Font.BOLD, 28));
		pub.setBounds(663, 426, 275, 56);
		contentPane.add(pub);
		
		JLabel self = new JLabel(pers.self);
		self.setForeground(Color.DARK_GRAY);
		self.setFont(new Font("Constantia", Font.BOLD, 28));
		self.setBounds(663, 486, 275, 56);
		contentPane.add(self);
		
		JLabel lack = new JLabel(pers.lack);
		lack.setForeground(Color.DARK_GRAY);
		lack.setFont(new Font("Constantia", Font.BOLD, 27));
		lack.setBounds(663, 451, 275, 67);
		contentPane.add(lack);
		
		JLabel slow = new JLabel(pers.slow);
		slow.setForeground(Color.DARK_GRAY);
		slow.setFont(new Font("Constantia", Font.BOLD, 28));
		slow.setBounds(663, 520, 275, 56);
		contentPane.add(slow);
		
		JLabel pros = new JLabel(pers.proc);
		pros.setForeground(Color.DARK_GRAY);
		pros.setFont(new Font("Constantia", Font.BOLD, 28));
		pros.setBounds(663, 397, 275, 56);
		contentPane.add(pros);
		
		JLabel typing = new JLabel(pers.typing);
		typing.setForeground(Color.DARK_GRAY);
		typing.setFont(new Font("Constantia", Font.BOLD, 30));
		typing.setBounds(663, 223, 197, 50);
		contentPane.add(typing);
		
		JLabel dedication = new JLabel(pers.dedication);
		dedication.setForeground(Color.DARK_GRAY);
		dedication.setFont(new Font("Constantia", Font.BOLD, 30));
		dedication.setBounds(663, 255, 221, 50);
		contentPane.add(dedication);
		
		JLabel multi = new JLabel(pers.multi);
		multi.setForeground(Color.DARK_GRAY);
		multi.setFont(new Font("Constantia", Font.BOLD, 30));
		multi.setBounds(663, 284, 221, 50);
		contentPane.add(multi);
		
		JLabel time = new JLabel(pers.time);
		time.setForeground(Color.DARK_GRAY);
		time.setFont(new Font("Constantia", Font.BOLD, 28));
		time.setBounds(663, 188, 275, 56);
		contentPane.add(time);
		
		JLabel creati = new JLabel(pers.crea);
		creati.setForeground(Color.DARK_GRAY);
		creati.setFont(new Font("Constantia", Font.BOLD, 30));
		creati.setBounds(663, 161, 135, 50);
		contentPane.add(creati);
		skill.setBounds(10, 11, 135, 50);
		skill.setIcon(new ImageIcon(img2));
		contentPane.add(skill);
		skills.setIcon(new ImageIcon(img));
		skills.setBounds(0, 0, 1230, 693);
		contentPane.add(skills);
	}

}
