package Profile;

public class personality extends information  {
	String calm = "•Calm";
	String creative = "•Creative";
	String depedable = "•Dependable";
	String flexible = "•Flexible";
	String introvert = "•Introvert";
	String mindful = "•Mindful";
		

}
