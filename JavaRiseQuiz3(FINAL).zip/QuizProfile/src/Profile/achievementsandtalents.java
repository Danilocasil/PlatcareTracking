package Profile;

import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class achievementsandtalents extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					achievementsandtalents frame = new achievementsandtalents();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public achievementsandtalents() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1239, 724);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel achievement = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("/Achievement.png")).getImage();
		Image img2 = new ImageIcon(this.getClass().getResource("/back.png")).getImage();
		
		JLabel achieve = new JLabel("");
		achieve.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				mainprofile mp = new mainprofile();
				mp.setVisible(true);
				mp.setLocationRelativeTo(null);
				dispose();
			}
		});
		achieve.setBounds(10, 11, 135, 50);
		contentPane.add(achieve);
		achieve.setIcon(new ImageIcon(img2));
		achievement.setIcon(new ImageIcon(img));
		achievement.setBounds(0, 0, 1230, 693);
		contentPane.add(achievement);
	}

}
